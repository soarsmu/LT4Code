python ../evaluator/evaluator.py -a ../dataset/review_data/test.jsonl  -p  saved_models_review/predictions.txt 
